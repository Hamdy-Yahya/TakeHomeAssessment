const { schedulesRouter } = require( './schedules.router' );

module.exports = {
    schedulesRouter
}