const { businessesRouter } = require( './businesses.router' );

module.exports = {
    businessesRouter
}