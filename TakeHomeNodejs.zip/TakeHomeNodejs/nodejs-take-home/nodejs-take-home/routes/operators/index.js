const { operatorsRouter } = require( './operators.router' );

module.exports = {
    operatorsRouter
}