const { opsRouter } = require( './ops.router' );

module.exports = {
    opsRouter
}