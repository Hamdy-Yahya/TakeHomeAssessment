const { operatorsRouter } = require( './operators' );

module.exports = {
    operatorsRouter
}